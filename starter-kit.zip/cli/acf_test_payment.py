#!/usr/bin/env python3
"""
AgenticTrade Payment Flow Smoke Test CLI.

Tests the complete payment cycle against a running ACF server:
  1. Health check
  2. Balance query
  3. Admin credit (test mode)
  4. Service listing
  5. Free tier proxy call
  6. Paid proxy call
  7. Balance verification

Usage:
    python acf_test_payment.py                              # Default: localhost:8092
    python acf_test_payment.py --url https://agentictrade.io
    python acf_test_payment.py --url http://localhost:8092 --api-key key:secret
"""
from __future__ import annotations

import argparse
import sys
import time

import httpx


def smoke_test(base_url: str, api_key: str, admin_secret: str, buyer_id: str) -> bool:
    client = httpx.Client(timeout=30)
    headers = {"Accept": "application/json"}
    if api_key:
        headers["Authorization"] = f"Bearer {api_key}"

    passed = 0
    total = 0

    def check(name: str, ok: bool, detail: str = ""):
        nonlocal passed, total
        total += 1
        mark = "\033[32mPASS\033[0m" if ok else "\033[31mFAIL\033[0m"
        print(f"  [{mark}] {name}" + (f" — {detail}" if detail and not ok else ""))
        if ok:
            passed += 1

    print(f"\n{'='*55}")
    print(f"  AgenticTrade Payment Smoke Test")
    print(f"  Server: {base_url}")
    print(f"{'='*55}\n")

    # 1. Health
    print("[1/7] Health check...")
    try:
        r = client.get(f"{base_url}/health")
        check("Server healthy", r.status_code == 200 and r.json().get("status") == "ok")
    except Exception as e:
        check("Server reachable", False, str(e))
        print(f"\nServer not reachable. Is it running at {base_url}?")
        return False

    # 2. Balance
    print("[2/7] Initial balance...")
    try:
        r = client.get(f"{base_url}/api/v1/balance/{buyer_id}")
        bal = r.json()
        check("Balance endpoint works", r.status_code == 200)
    except Exception as e:
        check("Balance query", False, str(e))

    # 3. Admin credit
    print("[3/7] Admin credit ($5)...")
    try:
        r = client.post(f"{base_url}/api/v1/admin/credit", params={
            "buyer_id": buyer_id, "amount": 5.0, "admin_key": admin_secret,
        })
        data = r.json()
        check("Credit applied", r.status_code == 200, f"status={r.status_code}")
    except Exception as e:
        check("Admin credit", False, str(e))

    # 4. List services
    print("[4/7] Service listing...")
    svc_id = None
    try:
        r = client.get(f"{base_url}/api/v1/services", headers=headers)
        services = r.json()
        has_services = isinstance(services, list) and len(services) > 0
        check("Services available", has_services, "no services found")
        if has_services:
            svc_id = services[0]["id"]
            print(f"         Using: {services[0]['name']}")
    except Exception as e:
        check("Service listing", False, str(e))

    if not svc_id:
        print("\nNo services to test against. Register a service first.")
        print(f"\nResult: {passed}/{total} passed")
        return False

    # 5. Free tier call
    print("[5/7] Free tier proxy call...")
    try:
        r = client.post(
            f"{base_url}/api/v1/proxy/{svc_id}/test",
            headers=headers, json={"test": True},
            params={"buyer_id": buyer_id},
        )
        free = r.headers.get("X-ACF-Free-Tier", "unknown")
        check("Proxy call OK", r.status_code < 500, f"status={r.status_code}")
    except Exception as e:
        check("Free tier call", False, str(e))

    # 6. Paid call (exhaust free tier)
    print("[6/7] Paid proxy call...")
    try:
        for _ in range(10):
            r = client.post(
                f"{base_url}/api/v1/proxy/{svc_id}/test",
                headers=headers, json={"test": True},
                params={"buyer_id": buyer_id},
            )
            if r.headers.get("X-ACF-Free-Tier") == "false":
                break
            time.sleep(0.2)
        amt = r.headers.get("X-ACF-Amount", "0")
        check("Paid call charged", float(amt) > 0, f"amount={amt}")
    except Exception as e:
        check("Paid call", False, str(e))

    # 7. Balance deducted
    print("[7/7] Balance verification...")
    try:
        r = client.get(f"{base_url}/api/v1/balance/{buyer_id}")
        new_bal = r.json().get("balance", 5.0)
        check("Balance deducted", new_bal < 5.0, f"balance={new_bal}")
    except Exception as e:
        check("Balance check", False, str(e))

    print(f"\n{'='*55}")
    color = "\033[32m" if passed == total else "\033[33m"
    print(f"  Result: {color}{passed}/{total} passed\033[0m")
    print(f"{'='*55}")
    return passed == total


def main():
    p = argparse.ArgumentParser(description="AgenticTrade payment smoke test")
    p.add_argument("--url", default="http://localhost:8092", help="Server URL")
    p.add_argument("--api-key", default="", help="API key (key_id:secret)")
    p.add_argument("--admin-secret", default="test-admin-secret", help="Admin secret")
    p.add_argument("--buyer-id", default="smoke-test-buyer", help="Test buyer ID")
    args = p.parse_args()

    ok = smoke_test(args.url, args.api_key, args.admin_secret, args.buyer_id)
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
