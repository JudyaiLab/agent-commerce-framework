# Chapter 2: Quick Start — Your First Agent Transaction

## Goal

By the end of this chapter, you'll have:
- A running ACF marketplace server
- A registered service
- A buyer agent that deposits funds and purchases the service
- A complete transaction with billing proof

Total time: ~15 minutes.

## Step 1: Start the Server

```bash
cd framework/
cp .env.example .env
docker compose up -d
```

Verify it's running:

```bash
curl http://localhost:8092/health
# {"status":"ok","version":"0.6.0","services":0}
```

> **No Docker?** Run directly:
> ```bash
> pip install -r requirements.txt
> uvicorn api.main:app --host 0.0.0.0 --port 8092
> ```

## Step 2: Register a Service

Let's register a simple "echo" service — it returns whatever you send it. In production, this would be your actual API.

```bash
curl -X POST http://localhost:8092/api/v1/services \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Echo Service",
    "description": "Returns your input — useful for testing the payment flow",
    "base_url": "https://httpbin.org",
    "price_per_call": 0.01,
    "free_tier_calls": 5,
    "category": "utility",
    "seller_id": "tutorial-seller"
  }'
```

Response:
```json
{
  "id": "svc_abc123...",
  "name": "Echo Service",
  "status": "active"
}
```

Save the service ID — you'll need it in Step 4.

```bash
export SERVICE_ID="svc_abc123"  # Replace with actual ID
```

## Step 3: Deposit Funds

Before a buyer agent can purchase services, it needs credits:

```bash
# Admin credit (test mode only — in production, use real payment)
curl -X POST "http://localhost:8092/api/v1/admin/credit?buyer_id=tutorial-buyer&amount=5.00&admin_key=test-admin-secret"
```

Verify the balance:

```bash
curl http://localhost:8092/api/v1/balance/tutorial-buyer
# {"buyer_id":"tutorial-buyer","balance":5.0}
```

Your buyer agent now has $5.00 in credits.

## Step 4: Make a Purchase

Now the buyer agent calls the service through the marketplace proxy:

```bash
curl -X POST "http://localhost:8092/api/v1/proxy/$SERVICE_ID/post" \
  -H "Content-Type: application/json" \
  -d '{"message": "Hello from my first agent transaction!"}' \
  -D - \
  | head -30
```

Look at the response headers:

```
X-ACF-Free-Tier: true        # First 5 calls are free
X-ACF-Amount: 0.00           # No charge for free tier
X-ACF-Balance: 5.00          # Balance unchanged
```

Make 6 more calls to exhaust the free tier:

```bash
for i in $(seq 1 6); do
  curl -s -X POST "http://localhost:8092/api/v1/proxy/$SERVICE_ID/post" \
    -H "Content-Type: application/json" \
    -d "{\"call\": $i}" \
    -o /dev/null -w "Call $i: %{http_code}\n"
done
```

Check the balance again:

```bash
curl http://localhost:8092/api/v1/balance/tutorial-buyer
# {"buyer_id":"tutorial-buyer","balance":4.99}
```

$0.01 was deducted for the first paid call (call #6).

## Step 5: Verify the Transaction

List all usage records:

```bash
curl "http://localhost:8092/api/v1/services/$SERVICE_ID/usage?buyer_id=tutorial-buyer"
```

You should see 6+ records — 5 free tier calls and at least 1 paid call.

## What Just Happened?

Let's trace the full flow:

```
1. Seller registered "Echo Service" → stored in DB with pricing rules
2. Buyer deposited $5.00 → balance credited (admin shortcut)
3. Buyer called proxy endpoint → ACF intercepted:
   a. Checked buyer balance ✓
   b. Checked free tier quota → first 5 calls free
   c. After free tier: deducted $0.01 per call
   d. Proxied request to https://httpbin.org/post (SSRF-safe)
   e. Logged usage record
   f. Returned response with billing headers
4. Seller's pending balance increased by $0.009 (after 10% platform fee)
```

## Automated Smoke Test

Instead of doing this manually, use the CLI tool:

```bash
python cli/acf_test_payment.py --url http://localhost:8092
```

This runs all 7 steps automatically and reports PASS/FAIL for each.

## Checkpoint

Before moving on, verify:

- [ ] Server running at `http://localhost:8092`
- [ ] At least 1 service registered
- [ ] Buyer has a balance
- [ ] Free tier calls work (no charge)
- [ ] Paid calls deduct from balance
- [ ] Usage records are logged

All checked? Let's dive into the architecture.

---

*Next: [Chapter 3 — Architecture Deep Dive →](./03-architecture.md)*
